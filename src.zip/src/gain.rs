pub struct GainStage {
    floor_gain: f32,
}

impl GainStage {
    pub fn new() -> Self {
        Self { floor_gain: 0.0 }
    }

    pub fn set_floor(&mut self, floor_db: f32) {
        self.floor_gain = nice_plug::util::db_to_gain(floor_db);
    }

    pub fn process(&self, envelope: f32) -> f32 {
        self.floor_gain + (1.0 - self.floor_gain) * envelope
    }
}

impl Default for GainStage {
    fn default() -> Self {
        Self::new()
    }
}
