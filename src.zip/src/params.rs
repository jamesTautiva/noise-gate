use nice_plug::prelude::*;

#[derive(Params)]
pub struct NoiseGateParams {
    #[id = "threshold"]
    pub threshold_db: FloatParam,

    #[id = "attack"]
    pub attack_ms: FloatParam,

    #[id = "release"]
    pub release_ms: FloatParam,

    #[id = "sidechain_hpf"]
    pub sidechain_hpf_hz: FloatParam,

    #[id = "floor"]
    pub floor_db: FloatParam,
}

impl Default for NoiseGateParams {
    fn default() -> Self {
        Self {
            threshold_db: FloatParam::new(
                "Threshold",
                -30.0,
                FloatRange::Linear { min: -60.0, max: 0.0 },
            )
            .with_unit(" dB"),

            attack_ms: FloatParam::new(
                "Attack",
                0.5,
                FloatRange::Skewed {
                    min: 0.01,
                    max: 50.0,
                    factor: FloatRange::skew_factor(-2.0),
                },
            )
            .with_unit(" ms"),

            release_ms: FloatParam::new(
                "Release",
                80.0,
                FloatRange::Skewed {
                    min: 5.0,
                    max: 1000.0,
                    factor: FloatRange::skew_factor(-2.0),
                },
            )
            .with_unit(" ms"),

            sidechain_hpf_hz: FloatParam::new(
                "Sidechain HPF",
                220.0,
                FloatRange::Skewed {
                    min: 20.0,
                    max: 800.0,
                    factor: FloatRange::skew_factor(-2.0),
                },
            )
            .with_unit(" Hz"),

            floor_db: FloatParam::new(
                "Floor",
                -80.0,
                FloatRange::Linear { min: -80.0, max: 0.0 },
            )
            .with_unit(" dB"),
        }
    }
}
