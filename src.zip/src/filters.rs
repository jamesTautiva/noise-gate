pub struct HighPassFilter {
    state: f32,
}

impl HighPassFilter {
    pub fn new() -> Self {
        Self { state: 0.0 }
    }

    pub fn process(&mut self, input: f32, alpha: f32) -> f32 {
        let output = alpha * (self.state + input - self.state);
        self.state = output;
        output.abs()
    }

    #[allow(dead_code)]
    pub fn reset(&mut self) {
        self.state = 0.0;
    }
}

impl Default for HighPassFilter {
    fn default() -> Self {
        Self::new()
    }
}
