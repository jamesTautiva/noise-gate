mod params;
mod filters;
mod detector;
mod envelope;
mod gain;
mod plugin;

use nice_plug::prelude::*;
use plugin::NoiseGate;

nice_export_vst3!(NoiseGate);