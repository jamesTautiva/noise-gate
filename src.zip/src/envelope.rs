pub struct EnvelopeFollower {
    envelope: f32,
    attack_coeff: f32,
    release_coeff: f32,
}

impl EnvelopeFollower {
    pub fn new() -> Self {
        Self {
            envelope: 0.0,
            attack_coeff: 0.0,
            release_coeff: 0.0,
        }
    }

    pub fn set_coefficients(&mut self, attack_coeff: f32, release_coeff: f32) {
        self.attack_coeff = attack_coeff;
        self.release_coeff = release_coeff;
    }

    pub fn process(&mut self, target: f32) -> f32 {
        let coeff = if target > self.envelope {
            self.attack_coeff
        } else {
            self.release_coeff
        };
        self.envelope = target + coeff * (self.envelope - target);
        self.envelope
    }

    #[allow(dead_code)]
    pub fn reset(&mut self) {
        self.envelope = 0.0;
    }
}

impl Default for EnvelopeFollower {
    fn default() -> Self {
        Self::new()
    }
}
