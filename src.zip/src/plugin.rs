use crate::params::NoiseGateParams;
use crate::filters::HighPassFilter;
use crate::detector::PeakDetector;
use crate::envelope::EnvelopeFollower;
use crate::gain::GainStage;
use nice_plug::prelude::*;
use nice_plug_egui::EguiState;
use std::sync::Arc;
use egui::{Color32, Pos2, Rect, Sense, Stroke, StrokeKind, Vec2};

pub struct NoiseGate {
    params: Arc<NoiseGateParams>,
    hpf: HighPassFilter,
    detector: PeakDetector,
    envelope: EnvelopeFollower,
    gain: GainStage,
}

impl Default for NoiseGate {
    fn default() -> Self {
        Self {
            params: Arc::new(NoiseGateParams::default()),
            hpf: HighPassFilter::default(),
            detector: PeakDetector::default(),
            envelope: EnvelopeFollower::default(),
            gain: GainStage::default(),
        }
    }
}

/// Helper para renderizar un Knob circular estilo Hardware
/// Helper para renderizar un Knob circular estilo Hardware con arco curvo
fn custom_knob(
    ui: &mut egui::Ui,
    value: &mut f32,
    range: std::ops::RangeInclusive<f32>,
    label: &str,
    unit: &str,
    diameter: f32,
    accent_color: Color32,
) -> egui::Response {
    let visual_diameter = diameter * 0.9;
    let desired_size = Vec2::splat(visual_diameter);
    let (rect, mut response) = ui.allocate_exact_size(desired_size, Sense::drag());

    if response.dragged() {
        let delta = response.drag_delta().y;
        let speed = (range.end() - range.start()) / 120.0;
        *value = (*value - delta * speed).clamp(*range.start(), *range.end());
        response.mark_changed();
    }

    if ui.is_rect_visible(rect) {
        let painter = ui.painter();
        let center = rect.center();
        let radius = visual_diameter / 2.0 - 2.0;

        // 1. Base del Knob
        painter.circle_filled(center, radius, Color32::from_rgb(25, 28, 34));
        painter.circle_stroke(center, radius, Stroke::new(2.0, Color32::from_rgb(45, 50, 60)));

        // 2. Ángulos (270° de recorrido)
        let normalized = (*value - range.start()) / (range.end() - range.start());
        let angle_start = std::f32::consts::PI * 0.75;
        let angle_end = std::f32::consts::PI * 2.25;
        let current_angle = angle_start + normalized * (angle_end - angle_start);

        // 3. ARCO CURVO (Matriz de puntos)
        let arc_radius = radius - 4.0;
        let steps = (30.0 * normalized).max(2.0) as usize; // Más definición si el valor es mayor
        let points: Vec<Pos2> = (0..=steps)
            .map(|i| {
                let t = i as f32 / steps as f32;
                let angle = angle_start + t * (current_angle - angle_start);
                Pos2 {
                    x: center.x + arc_radius * angle.cos(),
                    y: center.y + arc_radius * angle.sin(),
                }
            })
            .collect();

        if points.len() > 1 {
            for window in points.windows(2) {
                painter.line_segment([window[0], window[1]], Stroke::new(2.5, accent_color));
            }
        }

        // 4. Indicador en la punta
        let indicator_pos = Pos2 {
            x: center.x + arc_radius * current_angle.cos(),
            y: center.y + arc_radius * current_angle.sin(),
        };
        painter.circle_filled(indicator_pos, 3.0, accent_color);

        // 5. Texto informativo
        painter.text(
            Pos2 { x: center.x, y: rect.max.y + 12.0 },
            egui::Align2::CENTER_CENTER,
            format!("{} {:.1} {}", label, value, unit),
            egui::FontId::proportional(11.0),
            Color32::from_rgb(180, 190, 200),
        );
    }

    response
}

impl Plugin for NoiseGate {
    const NAME: &'static str = "DJENTCUT";
    const VENDOR: &'static str = "James Tautiva";
    const URL: &'static str = "https://example.com";
    const EMAIL: &'static str = "tu@email.com";
    const VERSION: &'static str = "0.1.0";

    const AUDIO_IO_LAYOUTS: &'static [AudioIOLayout] = &[AudioIOLayout {
        main_input_channels: NonZeroU32::new(2),
        main_output_channels: NonZeroU32::new(2),
        ..AudioIOLayout::const_default()
    }];

    type SysExMessage = ();
    type BackgroundTask = ();

    fn params(&self) -> Arc<dyn Params> {
        self.params.clone()
    }

    fn editor(&mut self, _async_executor: AsyncExecutor<Self>) -> Option<Box<dyn Editor>> {
        let params = self.params.clone();
        let egui_state = EguiState::from_size(800, 480);

        nice_plug_egui::create_egui_editor(
            egui_state,
            params.clone(),
            Default::default(),
            |ctx, queue, user_data| {
                let _ = queue;
                let _ = user_data;

                // Estilo Dark/Industrial
                let mut visuals = egui::Visuals::dark();
                visuals.panel_fill = Color32::from_rgb(14, 16, 20);
                visuals.widgets.noninteractive.bg_fill = Color32::from_rgb(22, 25, 30);
                ctx.set_visuals(visuals);
            },
            |ui, setter, queue, user_data| {
                let params = user_data.as_ref();
                let _ = queue;

                let cyan_neon = Color32::from_rgb(0, 240, 212);
                let orange_neon = Color32::from_rgb(255, 140, 0);

                egui::CentralPanel::default().show(ui, |ui| {
                    ui.add_space(8.0);

                    // 1. TOP BAR
                    ui.horizontal(|ui| {
                        ui.label(
                            egui::RichText::new("DJENTCUT")
                                .size(22.0)
                                .color(Color32::from_rgb(230, 235, 240))
                                .strong()
                                .monospace(),
                        );
                    });

                    ui.add_space(10.0);

                    // 2. MIDDLE PANEL: WAVEFORM GRAPH & GR METER
                    ui.horizontal(|ui| {
                        // Canvas principal de Onda y Threshold
                        let graph_size = Vec2::new(710.0, 160.0);
                        let (rect, _) = ui.allocate_exact_size(graph_size, Sense::hover());
                        let painter = ui.painter_at(rect);

                        // Fondo del display
                        painter.rect_filled(rect, 4.0, Color32::from_rgb(10, 12, 15));
                        painter.rect_stroke(
                            rect,
                            4.0,
                            Stroke::new(1.0, Color32::from_rgb(35, 40, 48)),
                            StrokeKind::Inside,
                        );

                        // Línea de THRESHOLD (Cyan)
                        let threshold_val = params.threshold_db.value();
                        let norm_thresh = (threshold_val + 60.0) / 60.0;
                        let thresh_y = rect.max.y - (norm_thresh * rect.height());

                        painter.line_segment(
                            [Pos2::new(rect.min.x, thresh_y), Pos2::new(rect.max.x, thresh_y)],
                            Stroke::new(1.5, cyan_neon),
                        );

                        painter.text(
                            Pos2::new(rect.max.x - 70.0, thresh_y - 10.0),
                            egui::Align2::LEFT_TOP,
                            "THRESHOLD LINE",
                            egui::FontId::monospace(9.0),
                            cyan_neon,
                        );

                        // Bloque Naranja de Gain Reduction
                        let chop_rect = Rect::from_min_max(
                            Pos2::new(rect.min.x + 400.0, thresh_y),
                            Pos2::new(rect.min.x + 550.0, rect.max.y - 5.0),
                        );
                        painter.rect_filled(chop_rect, 0.0, Color32::from_rgba_unmultiplied(255, 140, 0, 40));
                        painter.rect_stroke(chop_rect, 0.0, Stroke::new(1.0, orange_neon), StrokeKind::Inside);

                        ui.add_space(15.0);

                        // Vúmetro Vertical (GR Meter)
                        ui.vertical(|ui| {
                            ui.label(egui::RichText::new("GR").size(10.0).strong());
                            let meter_size = Vec2::new(12.0, 140.0);
                            let (m_rect, _) = ui.allocate_exact_size(meter_size, Sense::hover());
                            ui.painter().rect_filled(m_rect, 2.0, Color32::from_rgb(20, 22, 26));
                            ui.painter().rect_filled(
                                Rect::from_min_max(
                                    Pos2::new(m_rect.min.x, m_rect.min.y + 30.0),
                                    m_rect.max,
                                ),
                                2.0,
                                orange_neon,
                            );
                        });
                    });

                    ui.add_space(25.0);

                    // 3. BOTTOM PANEL: CONTROLES
                    ui.horizontal(|ui| {
                        ui.add_space(20.0);

                        // Sidechain HPF
                        let mut hpf = params.sidechain_hpf_hz.value();
                        if custom_knob(ui, &mut hpf, 20.0..=800.0, "SIDECHAIN HPF", "Hz", 50.0, cyan_neon).changed() {
                            setter.begin_set_parameter(&params.sidechain_hpf_hz);
                            setter.set_parameter(&params.sidechain_hpf_hz, hpf);
                            setter.end_set_parameter(&params.sidechain_hpf_hz);
                        }

                        ui.add_space(40.0);

                        // THRESHOLD (Knob Principal)
                        let mut threshold = params.threshold_db.value();
                        if custom_knob(ui, &mut threshold, -60.0..=0.0, "THRESHOLD", "dB", 80.0, cyan_neon).changed() {
                            setter.begin_set_parameter(&params.threshold_db);
                            setter.set_parameter(&params.threshold_db, threshold);
                            setter.end_set_parameter(&params.threshold_db);
                        }

                        ui.add_space(40.0);

                        // Release
                        let mut release = params.release_ms.value();
                        if custom_knob(ui, &mut release, 1.0..=1000.0, "RELEASE", "ms", 50.0, cyan_neon).changed() {
                            setter.begin_set_parameter(&params.release_ms);
                            setter.set_parameter(&params.release_ms, release);
                            setter.end_set_parameter(&params.release_ms);
                        }

                        ui.add_space(30.0);

                        // Attack
                        let mut attack = params.attack_ms.value();
                        if custom_knob(ui, &mut attack, 0.01..=50.0, "ATTACK", "ms", 50.0, cyan_neon).changed() {
                            setter.begin_set_parameter(&params.attack_ms);
                            setter.set_parameter(&params.attack_ms, attack);
                            setter.end_set_parameter(&params.attack_ms);
                        }

                        ui.add_space(40.0);

                        // Floor Slider Vertical
                        ui.vertical(|ui| {
                            ui.label(egui::RichText::new("FLOOR").size(11.0).strong());
                            let mut floor = params.floor_db.value();
                            let floor_res = ui.add(
                                egui::Slider::new(&mut floor, -80.0..=0.0)
                                    .vertical()
                                    .show_value(false),
                            );
                            if floor_res.changed() {
                                setter.begin_set_parameter(&params.floor_db);
                                setter.set_parameter(&params.floor_db, floor);
                                setter.end_set_parameter(&params.floor_db);
                            }
                            ui.label(egui::RichText::new(format!("{:.0} dB", floor)).size(10.0));
                        });
                    });

                    // Footer
                    ui.with_layout(egui::Layout::bottom_up(egui::Align::Center), |ui| {
                        ui.label(
                            egui::RichText::new("JAMES TAUTIVA DEV")
                                .size(10.0)
                                .color(Color32::from_rgb(100, 110, 120))
                                .strong(),
                        );
                    });
                });
            },
        )
    }

    fn process(
        &mut self,
        buffer: &mut Buffer,
        _aux: &mut AuxiliaryBuffers,
        context: &mut impl ProcessContext<Self>,
    ) -> ProcessStatus {
        let sample_rate = context.transport().sample_rate;

        let open_threshold = util::db_to_gain(self.params.threshold_db.value());
        let close_threshold = open_threshold * util::db_to_gain(-3.0);

        let hp_cutoff = self.params.sidechain_hpf_hz.value();
        let alpha = 1.0 / (1.0 + (2.0 * std::f32::consts::PI * hp_cutoff / sample_rate));

        let attack_time = (self.params.attack_ms.value() / 1000.0).max(0.0001);
        let release_time = (self.params.release_ms.value() / 1000.0).max(0.0001);

        let attack_coeff = (-1.0 / (sample_rate * attack_time)).exp();
        let release_coeff = (-1.0 / (sample_rate * release_time)).exp();

        self.detector.set_thresholds(open_threshold, close_threshold);
        self.envelope.set_coefficients(attack_coeff, release_coeff);
        self.gain.set_floor(self.params.floor_db.value());

        for mut sample_block in buffer.iter_samples() {
            let mut raw_peak = 0.0f32;
            for sample in sample_block.iter_mut() {
                raw_peak = raw_peak.max(sample.abs());
            }

            let filtered_peak = self.hpf.process(raw_peak, alpha);
            let is_open = self.detector.process(filtered_peak);
            let target_gain = if is_open { 1.0 } else { 0.0 };
            let envelope_value = self.envelope.process(target_gain);
            let final_gain = self.gain.process(envelope_value);

            for sample in sample_block.iter_mut() {
                *sample *= final_gain;
            }
        }

        ProcessStatus::Normal
    }
}

impl Vst3Plugin for NoiseGate {
    const VST3_CLASS_ID: [u8; 16] = *b"DjentCutPlugX012";
    const VST3_SUBCATEGORIES: &'static [Vst3SubCategory] =
        &[Vst3SubCategory::Fx, Vst3SubCategory::Dynamics];
}